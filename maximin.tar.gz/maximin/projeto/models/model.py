class World:
    def __init__(self,id,nome,raca,tipo,regiao):
        self.id=id
        self.nome=nome
        self.raca=raca
        self.tipo=tipo
        self.regiao=regiao
pokemon=[]
def add_poke(nome,raca,tipo,regiao):
    id=len(pokemon)+1
    novo_pokemon=World(id,nome,raca,tipo,regiao)
    pokemon.append(novo_pokemon)
