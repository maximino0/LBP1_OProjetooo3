from flask import Flask, Blueprint, render_template,request,redirect,url_for
from models.model import*

poke_controller=Blueprint('pokemon',__name__)
@poke_controller.route('/')
def index():
    return render_template('index.html',pokemon=pokemon)
@poke_controller.route("/tipo", methods=['POST'])
def html():
    opc=request.form['opcao']
    if opc=="sim":
        return render_template('tipo2.html',pokemon=pokemon)
    else:
        return render_template('tipo1.html',pokemon=pokemon)
@poke_controller.route("/add2", methods=['POST'])
def add_2():
    tipo=[]
    nome=request.form['campo1']
    tipo=[request.form['campo2'],request.form['campo6']]
    raca=request.form['campo3']
    regiao=request.form['campo4']
    add_poke(nome,raca,tipo,regiao)
    return redirect(url_for('pokemon.index'))
@poke_controller.route("/add1", methods=['POST'])
def add_1():
    tipo=[]
    nome=request.form['campo1']
    tipo=request.form['campo2']
    raca=request.form['campo3']
    regiao=request.form['campo4']
    add_poke(nome,raca,tipo,regiao)
    return redirect(url_for('pokemon.index'))
