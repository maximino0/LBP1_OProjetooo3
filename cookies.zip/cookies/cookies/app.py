from flask import Flask, render_template
from datetime import timedelta
from controllers.controller import*

app=Flask(__name__)

app.register_blueprint(login_controller)
app.secret_key = "sua-chave-secreta"
app.config['SESSION_COOKIE_SECURE'] = True
app.config['PERMANENT_SESSION_LIFETIME']=timedelta(days=7)

@app.errorhandler(404)
def pagina_nao_encontrada(e):
    return render_template('404.html'),404

@app.errorhandler(ZeroDivisionError)
def pagina_zero_divisao(e):
    return render_template('zero.html',message="Ocorreu uma divisão por zero!"),500

@app.errorhandler(401)
def pagina_nao_autorizada(e):
    return render_template('401.html', message="Você não está autorizado a acessar esta página."), 401

@app.errorhandler(403)
def pagina_proibida(e):
    return render_template('403.html', message="Acesso proibido! Você não tem permissão para visualizar esta página."), 403

@app.errorhandler(Exception)
def pagina_erro_generico(e):
    return render_template('generic_error.html',message=str(e)),500
if '__main__'==__name__:
    app.run(debug=True)