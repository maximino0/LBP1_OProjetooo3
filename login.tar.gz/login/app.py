from flask import Flask, render_template,session
from datetime import timedelta
from controllers.controllers import*

app=Flask(__name__)


app.register_blueprint(login_controller)
if '__main__'==__name__:
    app.run(debug=True)
