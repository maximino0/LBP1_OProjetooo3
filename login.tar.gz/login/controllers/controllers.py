from flask import Flask, Blueprint, render_template,request,redirect,url_for
from models.models import*

login_controller=Blueprint('log',__name__)
@login_controller.route('/')
def index():
    return render_template('index.html')
@login_controller.route('/log')
def ind():
    return render_template('ind.html')
@login_controller.route("/login", methods=['POST'])
def add():
    return redirect(url_for('log.ind'))
@login_controller.route("/logout", methods=['POST'])
def logout():
    return redirect(url_for('log.index'))